/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export class NotificationService {
  static async requestPermission() {
    if (!('Notification' in window)) return false;
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }

  static async send(title: string, body: string) {
    if (!('Notification' in window)) return;
    if (Notification.permission === 'granted') {
      new Notification(title, {
        body,
        icon: '/favicon.ico',
        dir: 'rtl'
      });
    }
  }

  static scheduleReminders() {
    // This is a simple implementation. In a real PWA we'd use Service Workers.
    // Here we check periodically or set timeouts.
    const reminders = [
      { time: '08:00', title: 'طقوس الصباح (3)', body: 'حان وقت إطلاق رغبتك 3 مرات بتركيز يقيني.' },
      { time: '14:00', title: 'طقوس النهار (6)', body: 'عزز إيمانك برغبتك، اكتبها الآن 6 مرات.' },
      { time: '21:00', title: 'طقوس المساء (9)', body: 'سلم رغبتك للكون، اكتبها 9 مرات قبل النوم.' }
    ];

    setInterval(() => {
      const now = new Date();
      const timeStr = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
      
      const ritual = reminders.find(r => r.time === timeStr);
      if (now.getSeconds() === 0 && ritual) {
        this.send(ritual.title, ritual.body);
      }
    }, 60000); // Check every minute
  }
}
