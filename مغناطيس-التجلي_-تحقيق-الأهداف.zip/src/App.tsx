/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Zap, 
  Target, 
  Plus, 
  Settings as SettingsIcon, 
  Home, 
  History, 
  Sparkles,
  Magnet,
  CheckCircle2,
  Brain
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { Goal, GoalStatus, AppState } from './types';
import GoalWizard from './components/GoalWizard';
import Dashboard from './components/Dashboard';
import ManifestationMagnet from './components/ManifestationMagnet';
import { NotificationService } from './lib/NotificationService';

const STORAGE_KEY = 'manifestation_magnet_data';

export default function App() {
  const [appState, setAppState] = useState<AppState>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) return { goals: [], activeGoalId: null };
    
    try {
      const parsed = JSON.parse(saved) as AppState;
      // Migration for rituals structure (3-6-9)
      const migratedGoals = parsed.goals.map(goal => {
        const rituals = goal.rituals as any;
        if (!rituals.morning || !rituals.midday || !rituals.evening) {
          return {
            ...goal,
            rituals: {
              morning: new Array(3).fill(false),
              midday: new Array(6).fill(false),
              evening: new Array(9).fill(false)
            }
          };
        }
        return goal;
      });
      return { ...parsed, goals: migratedGoals };
    } catch (e) {
      console.error('Failed to parse app state', e);
      return { goals: [], activeGoalId: null };
    }
  });

  const [activeView, setActiveView] = useState<'dashboard' | 'wizard' | 'ritual'>('dashboard');
  const [hasNotificationPermission, setHasNotificationPermission] = useState(false);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(appState));
  }, [appState]);

  useEffect(() => {
    NotificationService.scheduleReminders();
    if ('Notification' in window) {
      setHasNotificationPermission(Notification.permission === 'granted');
    }
  }, []);

  const handleRequestPermission = async () => {
    const granted = await NotificationService.requestPermission();
    setHasNotificationPermission(granted);
    if (granted) {
      NotificationService.send('تم تفعيل التنبيهات', 'سوف نذكرك بطقوس الـ 3-6-9 يومياً.');
    }
  };

  const addGoal = (goal: Goal) => {
    setAppState(prev => ({
      ...prev,
      goals: [...prev.goals, goal],
      activeGoalId: goal.id
    }));
    setActiveView('dashboard');
  };

  const updateGoal = (updatedGoal: Goal) => {
    setAppState(prev => ({
      ...prev,
      goals: prev.goals.map(g => g.id === updatedGoal.id ? updatedGoal : g)
    }));
  };

  const deleteGoal = (id: string) => {
    setAppState(prev => ({
      ...prev,
      goals: prev.goals.filter(g => g.id !== id),
      activeGoalId: prev.activeGoalId === id ? null : prev.activeGoalId
    }));
  };

  const startRitual = (id: string) => {
    setAppState(prev => ({ ...prev, activeGoalId: id }));
    setActiveView('ritual');
  };

  const activeGoal = appState.goals.find(g => g.id === appState.activeGoalId);

  return (
    <div className="min-h-screen bg-[#0a0518] text-gray-100 font-sans selection:bg-purple-500/30 overflow-x-hidden" dir="rtl">
      {/* Dynamic Background */}
      <div className="fixed inset-0 pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-900/20 blur-[120px] rounded-full" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-blue-900/20 blur-[120px] rounded-full" />
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-5" />
      </div>

      {/* Header */}
      <header className="sticky top-0 z-50 backdrop-blur-md bg-[#0a0518]/80 border-b border-white/5">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-500/20">
              <Magnet className="text-white w-6 h-6" />
            </div>
            <div>
              <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-400">
                مغناطيس التجلي
              </h1>
              <p className="text-[10px] text-purple-400 font-mono tracking-widest uppercase">Goal Achievement System</p>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-6">
            <button 
              onClick={() => setActiveView('dashboard')}
              className={`flex items-center gap-2 text-sm transition-colors ${activeView === 'dashboard' ? 'text-purple-400 font-medium' : 'text-gray-400 hover:text-white'}`}
            >
              <Home size={18} />
              <span>الرئيسية</span>
            </button>
            <button 
              onClick={() => setActiveView('wizard')}
              className={`flex items-center gap-2 text-sm transition-colors ${activeView === 'wizard' ? 'text-purple-400 font-medium' : 'text-gray-400 hover:text-white'}`}
            >
              <Plus size={18} />
              <span>هدف جديد</span>
            </button>
          </nav>

          <div className="flex items-center gap-4">
            {!hasNotificationPermission && (
              <button 
                onClick={handleRequestPermission}
                className="hidden md:flex items-center gap-2 bg-white/5 hover:bg-white/10 px-4 py-2 rounded-xl text-xs text-yellow-400 border border-yellow-500/20 transition-all"
              >
                <Zap size={14} />
                <span>تفعيل التنبيهات</span>
              </button>
            )}
            <div className="flex flex-col items-end mr-4">
              <span className="text-xs text-gray-500">الأهداف المحققة</span>
              <span className="text-sm font-bold text-green-400">
                {appState.goals.filter(g => g.status === GoalStatus.MANIFESTED).length}
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 max-w-7xl mx-auto px-4 py-8">
        <AnimatePresence mode="wait">
          {activeView === 'dashboard' && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <Dashboard 
                goals={appState.goals} 
                onStartRitual={startRitual}
                onDelete={deleteGoal}
                onCreateNew={() => setActiveView('wizard')}
              />
            </motion.div>
          )}

          {activeView === 'wizard' && (
            <motion.div
              key="wizard"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.05 }}
            >
              <GoalWizard onComplete={addGoal} onCancel={() => setActiveView('dashboard')} />
            </motion.div>
          )}

          {activeView === 'ritual' && activeGoal && (
            <motion.div
              key="ritual"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <ManifestationMagnet 
                goal={activeGoal} 
                onUpdate={updateGoal}
                onClose={() => setActiveView('dashboard')}
              />
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Mobile Navigation */}
      <nav className="md:hidden fixed bottom-6 left-1/2 -translate-x-1/2 bg-[#1a1135]/90 backdrop-blur-xl border border-white/10 px-8 py-4 rounded-full flex gap-12 z-50 shadow-2xl">
        <button 
          onClick={() => setActiveView('dashboard')}
          className={`flex flex-col items-center ${activeView === 'dashboard' ? 'text-purple-400' : 'text-gray-500'}`}
        >
          <Home size={24} />
        </button>
        <button 
          onClick={() => setActiveView('wizard')}
          className={`flex flex-col items-center p-3 -mt-10 bg-gradient-to-br from-purple-500 to-indigo-600 rounded-full shadow-lg shadow-purple-500/40 text-white`}
        >
          <Plus size={28} />
        </button>
        <button 
          onClick={() => setActiveView('dashboard')}
          className={`flex flex-col items-center ${activeView === 'ritual' ? 'text-purple-400' : 'text-gray-500'}`}
        >
          <Zap size={24} />
        </button>
      </nav>
    </div>
  );
}
