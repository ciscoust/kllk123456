/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  X, 
  Magnet, 
  Sparkles, 
  Moon, 
  Sun, 
  Sunrise, 
  Sunset, 
  Zap, 
  CheckCircle,
  Brain,
  Volume2,
  VolumeX
} from 'lucide-react';
import { Goal } from '../types';

interface ManifestationMagnetProps {
  goal: Goal;
  onUpdate: (goal: Goal) => void;
  onClose: () => void;
}

const ritualTimes = [
  { id: 'morning', name: 'الصباح', count: 3, icon: <Sunrise />, color: 'from-orange-400 to-yellow-500' },
  { id: 'midday', name: 'النهار', count: 6, icon: <Sun />, color: 'from-yellow-400 to-orange-500' },
  { id: 'evening', name: 'المساء', count: 9, icon: <Moon />, color: 'from-purple-500 to-indigo-600' }
];

export default function ManifestationMagnet({ goal, onUpdate, onClose }: ManifestationMagnetProps) {
  const [isMeditating, setIsMeditating] = useState(false);
  const [activeRitual, setActiveRitual] = useState<typeof ritualTimes[0] | null>(null);
  const [affirmationInput, setAffirmationInput] = useState('');
  const [completedCount, setCompletedCount] = useState(0);
  const [isMuted, setIsMuted] = useState(false);

  // Daily Reset Check
  useEffect(() => {
    const today = new Date().toISOString().split('T')[0];
    if (goal.lastRitualUpdate !== today) {
      const resetGoal = {
        ...goal,
        lastRitualUpdate: today,
        rituals: {
          morning: new Array(3).fill(false),
          midday: new Array(6).fill(false),
          evening: new Array(9).fill(false)
        }
      };
      onUpdate(resetGoal);
    }
  }, [goal, onUpdate]);

  const handleAffirmationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeRitual) return;
    
    if (affirmationInput.trim().length > 5) {
      const nextCount = completedCount + 1;
      setCompletedCount(nextCount);
      setAffirmationInput('');

      if (nextCount >= activeRitual.count) {
        // Mark ritual as complete in goal state
        const updatedGoal = { ...goal };
        const key = activeRitual.id as keyof typeof goal.rituals;
        updatedGoal.rituals[key] = updatedGoal.rituals[key].map(() => true);
        onUpdate(updatedGoal);
        
        // Visual reward then close ritual session
        setTimeout(() => {
          setActiveRitual(null);
          setCompletedCount(0);
        }, 1500);
      }
    }
  };

  const getDayProgress = () => {
    const total = 3 + 6 + 9;
    const done = Object.values(goal.rituals).flat().filter(Boolean).length;
    return (done / total) * 100;
  };

  const particles = Array.from({ length: 40 });

  return (
    <div className="fixed inset-0 z-[100] bg-[#0a0518] flex flex-col overflow-hidden" dir="rtl">
      {/* Background Ambience */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <motion.div 
          animate={{ scale: [1, 1.2, 1], opacity: [0.1, 0.2, 0.1] }}
          transition={{ duration: 10, repeat: Infinity }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-purple-500/10 blur-[150px] rounded-full" 
        />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_transparent_0%,_#0a0518_70%)]" />
      </div>

      {/* Header */}
      <div className="relative z-10 flex items-center justify-between p-6">
        <div className="flex items-center gap-4">
          <button 
            onClick={onClose}
            className="w-12 h-12 bg-white/5 hover:bg-white/10 rounded-2xl flex items-center justify-center text-gray-400 hover:text-white transition-all"
          >
            <X size={24} />
          </button>
          <div>
            <h2 className="text-xl font-bold text-white line-clamp-1">{goal.title}</h2>
            <p className="text-xs text-purple-400 uppercase tracking-widest font-mono">Quantum Extraction 3-6-9</p>
          </div>
        </div>

        <button 
          onClick={() => setIsMuted(!isMuted)}
          className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center text-gray-400"
        >
          {isMuted ? <VolumeX size={20} /> : <Volume2 size={20} />}
        </button>
      </div>

      {/* Main Attraction Zone */}
      <div className="flex-grow relative flex flex-col items-center justify-center p-8">
        <AnimatePresence mode="wait">
          {!activeRitual ? (
            <motion.div 
              key="main"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              className="relative z-20 flex flex-col items-center w-full max-w-2xl"
            >
              {/* Central Magnet Visual */}
              <div className="relative mb-12">
                <motion.div 
                  animate={{ scale: [1, 1.15, 1], opacity: [0.3, 0.6, 0.3] }}
                  transition={{ duration: 4, repeat: Infinity }}
                  className="absolute inset-0 bg-purple-500/30 blur-3xl rounded-full"
                />
                <div className="w-40 h-40 bg-gradient-to-br from-purple-600 to-indigo-700 rounded-full flex items-center justify-center relative z-10 shadow-2xl shadow-purple-500/50 border-4 border-white/10">
                  <Magnet className="text-white w-20 h-20" />
                </div>
              </div>

              <h1 className="text-3xl font-bold text-center mb-8 text-white">اختر طقس التجلي الحالي</h1>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full">
                {ritualTimes.map((ritual) => {
                  const isDone = goal.rituals[ritual.id as keyof typeof goal.rituals].every(Boolean);
                  return (
                    <button
                      key={ritual.id}
                      disabled={isDone}
                      onClick={() => {
                        setActiveRitual(ritual);
                        setCompletedCount(0);
                      }}
                      className={`group relative p-6 rounded-[32px] border transition-all flex flex-col items-center gap-4 ${
                        (goal.rituals[ritual.id as keyof typeof goal.rituals] || []).every(Boolean) 
                          ? 'bg-green-500/10 border-green-500/20 opacity-60 cursor-default' 
                          : 'bg-white/5 border-white/5 hover:border-purple-500/30 hover:bg-white/10'
                      }`}
                    >
                      <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${ritual.color} flex items-center justify-center text-white shadow-lg`}>
                        {(goal.rituals[ritual.id as keyof typeof goal.rituals] || []).every(Boolean) ? <CheckCircle size={28} /> : ritual.icon}
                      </div>
                      <div className="text-center">
                        <span className="block text-lg font-bold text-white mb-1">{ritual.name}</span>
                        <span className="block text-xs text-gray-500 font-mono">كرر {ritual.count} مرات</span>
                      </div>
                      {(goal.rituals[ritual.id as keyof typeof goal.rituals] || []).every(Boolean) && <div className="absolute top-4 right-4 text-green-400 text-[10px] font-bold uppercase">مكتمل</div>}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="active-ritual"
              initial={{ opacity: 0, scale: 1.1 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="relative z-30 w-full max-w-xl flex flex-col items-center"
            >
              <div className="mb-8 text-center">
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-br ${activeRitual.color} flex items-center justify-center text-white mx-auto mb-4 shadow-xl`}>
                  {activeRitual.icon}
                </div>
                <h2 className="text-2xl font-bold text-white mb-2">طقوس {activeRitual.name}</h2>
                <p className="text-purple-400 font-mono tracking-widest text-sm">التكرار: {completedCount} / {activeRitual.count}</p>
              </div>

              <div className="w-full bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-xl">
                <form onSubmit={handleAffirmationSubmit} className="space-y-6">
                  <div className="space-y-2">
                    <label className="text-sm text-gray-400 block px-2">اكتب توكيدك الآن بتركيز ويقين:</label>
                    <input 
                      autoFocus
                      type="text"
                      className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-white text-lg focus:outline-none focus:ring-2 focus:ring-purple-500/50 transition-all text-center"
                      placeholder="أنا الآن أستحق وأجذب..."
                      value={affirmationInput}
                      onChange={(e) => setAffirmationInput(e.target.value)}
                    />
                  </div>
                  
                  <div className="flex flex-col items-center gap-4">
                    <button 
                      type="submit"
                      disabled={affirmationInput.trim().length <= 5}
                      className="w-full bg-gradient-to-br from-purple-500 to-indigo-600 py-4 rounded-2xl text-white font-bold shadow-xl shadow-purple-500/20 disabled:opacity-30 transition-all hover:scale-[1.02] active:scale-[0.98]"
                    >
                      تأكيد التوكيد ({completedCount + 1})
                    </button>
                    <button 
                      type="button"
                      onClick={() => setActiveRitual(null)}
                      className="text-gray-500 text-sm hover:text-gray-300 transition-colors"
                    >
                      خروج من الجلسة
                    </button>
                  </div>
                </form>
              </div>

              {/* Progress Dots */}
              <div className="flex gap-2 mt-8">
                {Array.from({ length: activeRitual.count }).map((_, i) => (
                  <motion.div 
                    key={i}
                    animate={{ 
                      scale: i < completedCount ? 1.2 : 1,
                      backgroundColor: i < completedCount ? '#a855f7' : 'rgba(255,255,255,0.1)'
                    }}
                    className="w-3 h-3 rounded-full"
                  />
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Progress Footer */}
      <div className="p-8 bg-[#1a1135]/80 border-t border-white/5 relative z-10 backdrop-blur-md">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row gap-8 items-center justify-between">
          <div className="flex gap-12">
            <div className="flex flex-col">
              <span className="text-[10px] text-gray-500 uppercase tracking-widest mb-1">التقدم اليومي</span>
              <div className="flex items-center gap-3">
                <div className="h-1.5 w-32 bg-white/5 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${getDayProgress()}%` }}
                    className="h-full bg-gradient-to-r from-green-400 to-emerald-500"
                  />
                </div>
                <span className="text-xs font-bold text-white">{Math.round(getDayProgress())}%</span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-6">
            <div className="flex flex-col text-right">
              <span className="text-[10px] text-gray-500 uppercase tracking-widest mb-1">حالة التردد</span>
              <span className="text-sm text-purple-400 font-mono animate-pulse">3-6-9 RESONANCE ACTIVE</span>
            </div>
            <div className="w-12 h-12 bg-white/5 rounded-2xl flex items-center justify-center text-purple-400 border border-white/5">
              <Brain size={24} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
