/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowRight, 
  ArrowLeft, 
  Sparkles, 
  Heart, 
  ShieldCheck, 
  Coins, 
  Clock, 
  Crown,
  Lock,
  Zap,
  Target
} from 'lucide-react';
import { Goal, GoalStatus } from '../types';

interface wizardStep {
  id: string;
  title: string;
  question: string;
  description?: string;
  icon: React.ReactNode;
  field: keyof Omit<Goal, 'id' | 'createdAt' | 'status' | 'rituals'>;
}

const steps: wizardStep[] = [
  {
    id: 'desire',
    title: 'الرغبة المشتعلة',
    question: 'ماذا تريد بالضبط؟',
    description: 'حدد هدفك بوضوح تام، كأنك تراه أمامك الآن.',
    icon: <Target className="text-red-400" />,
    field: 'title'
  },
  {
    id: 'source',
    title: 'المصدر الأسمى',
    question: 'ممن تطلب هذه الرغبة؟',
    description: 'تذكر أن الله هو الرزاق الوهاب.',
    icon: <Crown className="text-yellow-400" />,
    field: 'source'
  },
  {
    id: 'why',
    title: 'محرك الشغف',
    question: 'لماذا تريد هذا الهدف؟',
    description: 'ما هي الغاية العميقة التي ستحققها؟',
    icon: <Heart className="text-pink-400" />,
    field: 'reason'
  },
  {
    id: 'worthiness',
    title: 'الاستحقاق',
    question: 'هل تؤمن أنك تستحق هذا الهدف؟ وبماذا تدل بذلك؟',
    description: 'أثبت لنفسك أنك وعاء مناسب لهذا الرزق.',
    icon: <ShieldCheck className="text-blue-400" />,
    field: 'worthiness'
  },
  {
    id: 'readiness',
    title: 'الاستعداد المادي والمعنوي',
    question: 'هل انت مستعد لاستقبال ما تريد؟',
    description: 'كيف جهزت حياتك ومكانك لاستقبال هذا الهدف؟',
    icon: <Clock className="text-cyan-400" />,
    field: 'readiness'
  },
  {
    id: 'feeling',
    title: 'تردد السعادة',
    question: 'ما هو شعورك واحساسك عند حصولك على هذه الرغبة؟',
    description: 'عش اللحظة الآن، اشعر بالفرح والامتنان.',
    icon: <Sparkles className="text-orange-400" />,
    field: 'feeling'
  },
  {
    id: 'gratitude',
    title: 'موجة الشكر',
    question: 'هل انت شاكر لله على تحقق هذه الرغبة والرغبات السابقة؟',
    description: 'الحمد يزيد النعم، سجل كلمات شكرك.',
    icon: <Zap className="text-green-400" />,
    field: 'gratitude'
  },
  {
    id: 'sacrifice',
    title: 'قانون التضحية',
    question: 'ماذا سوف تقدم من تضحية (وقت، جهد، عادة)؟',
    description: 'لا شيء ينجذب بدون فراغ مسبق تخلقه بالتضحية.',
    icon: <Lock className="text-purple-400" />,
    field: 'sacrifice'
  },
  {
    id: 'offering',
    title: 'القربان',
    question: 'ما هو القربان الذي ستقدمه قبل الوصول؟',
    description: 'صدقة، إحسان، أو عمل صالح بنية التيسير.',
    icon: <Coins className="text-amber-400" />,
    field: 'offering'
  },
  {
    id: 'vow',
    title: 'النذر المقدس',
    question: 'ما هو النذر الذي ستفعله إذا تحقق ما تريد؟',
    description: 'عهد تلتزم به عند الوصول للهدف.',
    icon: <ShieldCheck className="text-indigo-400" />,
    field: 'vow'
  },
  {
    id: 'covenant',
    title: 'العهد المستمر',
    question: 'ما هو العهد الذي سوف تستمر عليه بعد التحقق؟',
    description: 'كيف ستحافظ على هذه النعمة؟',
    icon: <ArrowRight className="text-teal-400" />,
    field: 'covenant'
  }
];

export default function GoalWizard({ onComplete, onCancel }: { onComplete: (goal: Goal) => void, onCancel: () => void }) {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<Partial<Goal>>({
    visualizationMinutes: 5,
    status: GoalStatus.ATTRACTING
  });

  const step = steps[currentStep];
  const isLastStep = currentStep === steps.length - 1;

  const handleNext = () => {
    if (isLastStep) {
      const finalGoal: Goal = {
        ...(formData as Goal),
        id: Math.random().toString(36).substr(2, 9),
        createdAt: Date.now(),
        status: GoalStatus.ATTRACTING,
        lastRitualUpdate: new Date().toISOString().split('T')[0],
        rituals: {
          morning: new Array(3).fill(false),
          midday: new Array(6).fill(false),
          evening: new Array(9).fill(false)
        }
      };
      onComplete(finalGoal);
    } else {
      setCurrentStep(prev => prev + 1);
    }
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <button onClick={onCancel} className="text-gray-500 hover:text-white transition-colors">إلغاء</button>
          <span className="text-purple-400 font-mono text-sm">خطوة {currentStep + 1} / {steps.length}</span>
        </div>
        <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
          <motion.div 
            className="h-full bg-gradient-to-r from-purple-500 to-indigo-600"
            initial={{ width: 0 }}
            animate={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
          />
        </div>
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={step.id}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="bg-[#1a1135] border border-white/10 rounded-3xl p-8 shadow-2xl shadow-purple-500/5 relative overflow-hidden"
        >
          {/* Subtle icon background */}
          <div className="absolute top-0 right-0 p-12 opacity-[0.03] scale-[4] pointer-events-none">
            {step.icon}
          </div>

          <div className="flex items-center gap-4 mb-6">
            <div className="w-12 h-12 rounded-2xl bg-white/5 flex items-center justify-center">
              {step.icon}
            </div>
            <div>
              <h2 className="text-xl font-bold text-white">{step.title}</h2>
              <p className="text-sm text-gray-400">{step.description}</p>
            </div>
          </div>

          <div className="space-y-6">
            <label className="block">
              <span className="text-lg font-medium text-purple-200 mb-3 block">{step.question}</span>
              <textarea
                autoFocus
                className="w-full bg-white/5 border border-white/10 rounded-2xl p-4 text-white focus:outline-none focus:ring-2 focus:ring-purple-500/50 transition-all min-h-[120px] resize-none"
                placeholder="اكتب هنا بتركيز تام..."
                value={(formData[step.field] as string) || ''}
                onChange={(e) => setFormData({ ...formData, [step.field]: e.target.value })}
              />
            </label>

            <div className="flex justify-between items-center pt-6">
              <button
                disabled={currentStep === 0}
                onClick={() => setCurrentStep(prev => prev - 1)}
                className={`flex items-center gap-2 px-6 py-3 rounded-2xl transition-all ${currentStep === 0 ? 'opacity-0' : 'bg-white/5 text-gray-400 hover:bg-white/10 hover:text-white'}`}
              >
                <ArrowRight size={20} />
                <span>السابق</span>
              </button>

              <button
                disabled={!formData[step.field]}
                onClick={handleNext}
                className="flex items-center gap-2 bg-gradient-to-br from-purple-500 to-indigo-600 px-10 py-4 rounded-2xl text-white font-bold shadow-lg shadow-purple-500/20 hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 disabled:grayscale"
              >
                <span>{isLastStep ? 'إطلاق الرغبة' : 'التالي'}</span>
                {isLastStep ? <Sparkles size={20} /> : <ArrowLeft size={20} />}
              </button>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
    </div>
  );
}
