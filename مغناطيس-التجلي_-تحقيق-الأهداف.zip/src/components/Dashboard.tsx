/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { 
  Plus, 
  Magnet, 
  Trash2, 
  ExternalLink, 
  CheckCircle2, 
  Clock,
  Sparkles,
  Zap,
  Target
} from 'lucide-react';
import { Goal, GoalStatus } from '../types';

interface DashboardProps {
  goals: Goal[];
  onStartRitual: (id: string) => void;
  onDelete: (id: string) => void;
  onCreateNew: () => void;
}

export default function Dashboard({ goals, onStartRitual, onDelete, onCreateNew }: DashboardProps) {
  if (goals.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-8">
        <motion.div 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="w-24 h-24 bg-white/5 rounded-full flex items-center justify-center mb-8 border border-white/10"
        >
          <Magnet className="text-purple-500 w-12 h-12" />
        </motion.div>
        <h2 className="text-3xl font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-white to-gray-500">مرحباً بك في عالم التجلي</h2>
        <p className="text-gray-400 max-w-md mb-10 leading-relaxed text-lg">
          لا يوجد أهداف نشطة حالياً. هل أنت مستعد لإطلاق أول رغبة وتحويلها إلى واقع ملموس؟
        </p>
        <button 
          className="group relative px-8 py-4 bg-purple-600 rounded-2xl font-bold flex items-center gap-3 hover:bg-purple-500 transition-all shadow-xl shadow-purple-900/20"
          onClick={onCreateNew}
        >
          <Plus size={24} />
          <span>ابدأ الآن</span>
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-12 pb-24">
      {/* Stats Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-[#1a1135] border border-white/5 p-6 rounded-3xl flex items-center gap-6 shadow-xl">
          <div className="w-14 h-14 bg-purple-500/10 rounded-2xl flex items-center justify-center text-purple-400">
            <Target size={28} />
          </div>
          <div>
            <p className="text-xs text-gray-500 uppercase tracking-widest mb-1">الأهداف النشطة</p>
            <p className="text-2xl font-bold text-white">{goals.filter(g => g.status === GoalStatus.ATTRACTING).length}</p>
          </div>
        </div>
        
        <div className="bg-[#1a1135] border border-white/5 p-6 rounded-3xl flex items-center gap-6 shadow-xl">
          <div className="w-14 h-14 bg-green-500/10 rounded-2xl flex items-center justify-center text-green-400">
            <CheckCircle2 size={28} />
          </div>
          <div>
            <p className="text-xs text-gray-500 uppercase tracking-widest mb-1">أهداف تحققت</p>
            <p className="text-2xl font-bold text-white">{goals.filter(g => g.status === GoalStatus.MANIFESTED).length}</p>
          </div>
        </div>

        <div className="bg-[#1a1135] border border-white/5 p-6 rounded-3xl flex items-center gap-6 shadow-xl">
          <div className="w-14 h-14 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-400">
            <Zap size={28} />
          </div>
          <div>
            <p className="text-xs text-gray-500 uppercase tracking-widest mb-1">جلسات التجلي</p>
            <p className="text-2xl font-bold text-white">42</p> {/* Static for now or derive from data */}
          </div>
        </div>
      </div>

      {/* Goals Grid */}
      <div>
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold flex items-center gap-3">
            <Sparkles className="text-purple-400" />
            <span>قائمة الأهداف</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {goals.map((goal) => (
            <motion.div
              layoutId={goal.id}
              key={goal.id}
              whileHover={{ y: -5 }}
              className="bg-[#1a1135] border border-white/10 rounded-[32px] p-6 group hover:border-purple-500/30 transition-all flex flex-col h-full shadow-lg relative overflow-hidden"
            >
              <div className="absolute -top-12 -right-12 w-24 h-24 bg-purple-500/10 blur-2xl rounded-full" />
              
              <div className="flex justify-between items-start mb-6">
                <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                  goal.status === GoalStatus.MANIFESTED ? 'bg-green-500/10 text-green-400 border border-green-500/20' : 'bg-purple-500/10 text-purple-400 border border-purple-500/20'
                }`}>
                  {goal.status === GoalStatus.MANIFESTED ? 'تحقق بنجاح' : 'جاري الجذب'}
                </div>
                <button 
                  onClick={() => onDelete(goal.id)}
                  className="text-gray-600 hover:text-red-400 p-2 rounded-lg hover:bg-red-500/5 transition-all"
                >
                  <Trash2 size={18} />
                </button>
              </div>

              <h3 className="text-xl font-bold text-white mb-3 line-clamp-2 min-h-[56px] leading-snug">
                {goal.title}
              </h3>
              
              <div className="mb-6">
                <div className="flex justify-between text-[10px] text-gray-500 mb-1.5 uppercase font-mono tracking-tighter">
                  <span>التقدم اليومي (3-6-9)</span>
                  <span>{Math.round(((Object.values(goal.rituals || {}).flat().filter(Boolean).length) / 18) * 100)}%</span>
                </div>
                <div className="h-1 w-full bg-white/5 rounded-full overflow-hidden">
                  <motion.div 
                    initial={{ width: 0 }}
                    animate={{ width: `${((Object.values(goal.rituals || {}).flat().filter(Boolean).length) / 18) * 100}%` }}
                    className="h-full bg-gradient-to-r from-purple-500 to-indigo-500"
                  />
                </div>
              </div>

              <p className="text-gray-400 text-sm mb-6 flex-grow line-clamp-2">
                {goal.reason}
              </p>

              <div className="space-y-4 pt-6 border-t border-white/5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-gray-500 flex items-center gap-1.5">
                    <Clock size={14} />
                    {new Date(goal.createdAt).toLocaleDateString('ar-EG')}
                  </span>
                  <span className="text-purple-400 font-medium">3-6-9 Ritual Active</span>
                </div>

                <div className="flex gap-3">
                  <button 
                    onClick={() => onStartRitual(goal.id)}
                    className="flex-grow bg-white/5 hover:bg-white/10 text-white rounded-2xl py-3 px-4 text-sm font-bold flex items-center justify-center gap-2 transition-all border border-white/5"
                  >
                    <Magnet size={16} className="text-purple-400" />
                    <span>جلسة جذب</span>
                  </button>
                  <button className="p-3 bg-white/5 hover:bg-white/10 text-gray-400 rounded-2xl transition-all border border-white/5">
                    <ExternalLink size={18} />
                  </button>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
