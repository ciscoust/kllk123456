/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum GoalStatus {
  PLANNING = 'PLANNING',
  ATTRACTING = 'ATTRACTING',
  MANIFESTED = 'MANIFESTED',
  CELEBRATING = 'CELEBRATING'
}

export interface Goal {
  id: string;
  title: string;
  source: string;
  reason: string;
  worthiness: string;
  readiness: string;
  feeling: string;
  gratitude: string;
  sacrifice: string;
  offering: string;
  vow: string;
  covenant: string;
  visualizationMinutes: number;
  createdAt: number;
  status: GoalStatus;
  lastRitualUpdate?: string; // YYYY-MM-DD
  rituals: {
    morning: boolean[]; // 3 items
    midday: boolean[];  // 6 items
    evening: boolean[]; // 9 items
  };
}

export interface AppState {
  goals: Goal[];
  activeGoalId: string | null;
}
