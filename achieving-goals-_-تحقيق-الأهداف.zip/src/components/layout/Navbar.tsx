import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { AR } from '../../constants';
import { LogOut, User as UserIcon, Sparkles } from 'lucide-react';

export const Navbar: React.FC = () => {
  const { user, logout } = useAuth();

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 px-6 py-4" dir="rtl">
      <div className="max-w-7xl mx-auto flex items-center justify-between glass px-6 py-3 rounded-2xl border-white/5">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-brand-gold/20 rounded-xl flex items-center justify-center border border-brand-gold/30">
            <Sparkles className="w-6 h-6 text-brand-gold" />
          </div>
          <span className="text-xl font-display font-medium text-brand-gold">{AR.appName}</span>
        </div>

        {user && (
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-3 px-4 py-2 bg-white/5 rounded-xl border border-white/10">
              <span className="text-sm font-medium">{user.displayName}</span>
              <div className="w-8 h-8 rounded-full overflow-hidden border border-brand-gold/50">
                <img src={user.photoURL || `https://ui-avatars.com/api/?name=${user.displayName}`} alt={user.displayName || ''} />
              </div>
            </div>
            <button
              onClick={() => logout()}
              className="p-2 hover:bg-red-500/10 hover:text-red-500 rounded-xl transition-all text-white/50"
              title={AR.auth.logout}
            >
              <LogOut className="w-6 h-6" />
            </button>
          </div>
        )}
      </div>
    </nav>
  );
};
