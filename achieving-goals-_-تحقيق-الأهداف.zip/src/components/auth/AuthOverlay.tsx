import React from 'react';
import { useAuth } from '../../context/AuthContext';
import { signInWithGoogle } from '../../lib/firebase';
import { AR } from '../../constants';
import { LogIn } from 'lucide-react';
import { motion } from 'motion/react';

export const AuthOverlay: React.FC = () => {
  const { user, loading } = useAuth();

  if (loading || user) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-brand-deep/80 backdrop-blur-md p-4" dir="rtl">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="glass p-8 rounded-3xl max-w-md w-full text-center space-y-6 border-brand-gold/20"
      >
        <div className="space-y-2">
          <h1 className="text-4xl font-display font-bold text-brand-gold">{AR.appName}</h1>
          <p className="text-white/60 italic">"{AR.motto}"</p>
        </div>
        
        <div className="py-8">
          <motion.div 
            animate={{ scale: [1, 1.05, 1] }}
            transition={{ duration: 4, repeat: Infinity }}
            className="w-24 h-24 mx-auto rounded-full bg-brand-gold/10 flex items-center justify-center border border-brand-gold/30"
          >
            <LogIn className="w-10 h-10 text-brand-gold" />
          </motion.div>
        </div>

        <button
          onClick={signInWithGoogle}
          className="w-full py-4 px-6 bg-white text-brand-deep rounded-xl font-bold flex items-center justify-center gap-3 hover:bg-brand-gold transition-colors duration-300 shadow-lg shadow-brand-gold/10"
        >
          <img src="https://www.google.com/favicon.ico" alt="Google" className="w-5 h-5" />
          {AR.auth.login}
        </button>
      </motion.div>
    </div>
  );
};
