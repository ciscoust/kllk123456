import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { AR } from '../../constants';
import { useGoals } from '../../context/GoalContext';
import { Check, ArrowRight, ArrowLeft, Target, Heart, Sparkles, Gift, Scroll } from 'lucide-react';
import toast from 'react-hot-toast';

interface Step {
  id: string;
  title: string;
  icon: any;
  field: string;
  placeholder: string;
}

const steps: Step[] = [
  { id: 'target', title: AR.steps.desire, icon: Target, field: 'desire', placeholder: "أرغب في إطلاق تطبيقي (تحقيق الأهداف) متعدد المنصات..." },
  { id: 'why', title: "لماذا تريد؟", icon: Heart, field: 'why', placeholder: "لأني المناسب لعمله بحكم اطلاعي على هذا الموضوع..." },
  { id: 'worthiness', title: AR.steps.worthiness, icon: Sparkles, field: 'worthiness', placeholder: "أنا أستحق الحصول على هذا التطبيق المميز..." },
  { id: 'sacrifice', title: AR.steps.sacrifice, icon: Gift, field: 'sacrifice', placeholder: "ماذا ستقدم من تضحية؟ (ساعة لتعليم هذه العلوم، مبلغ مالي...)" },
  { id: 'vow', title: AR.steps.vow, icon: Scroll, field: 'vow', placeholder: "ما هو النذر الذي ستعاهد الله عليه بعد التحقق؟" },
];

export const RitualStepper: React.FC<{ onComplete: () => void }> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [formData, setFormData] = useState<any>({});
  const { addGoal } = useGoals();

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(curr => curr + 1);
    } else {
      handleSubmit();
    }
  };

  const handlePrev = () => {
    if (currentStep > 0) setCurrentStep(curr => curr - 1);
  };

  const handleSubmit = async () => {
    if (!formData.desire) {
      toast.error("يرجى إدخال الرغبة الأساسية أولاً");
      return;
    }
    await addGoal(formData);
    toast.success("تم إطلاق الهدف في الكون بنجاح");
    onComplete();
  };

  const current = steps[currentStep];

  return (
    <div className="w-full max-w-2xl mx-auto glass p-8 rounded-3xl space-y-8" dir="rtl">
      {/* Progress Bar */}
      <div className="flex gap-2">
        {steps.map((_, i) => (
          <div 
            key={i} 
            className={`h-1 flex-1 rounded-full transition-colors duration-500 ${i <= currentStep ? 'bg-brand-gold' : 'bg-white/10'}`}
          />
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 20 }}
          className="space-y-6"
        >
          <div className="flex items-center gap-4">
            <div className="p-3 bg-brand-gold/10 rounded-2xl border border-brand-gold/30">
              <current.icon className="w-8 h-8 text-brand-gold" />
            </div>
            <h2 className="text-2xl font-display font-bold">{current.title}</h2>
          </div>

          <textarea
            autoFocus
            className="w-full h-40 bg-white/5 border border-white/10 rounded-2xl p-6 text-xl focus:border-brand-gold/50 outline-none transition-all placeholder:text-white/20 resize-none font-sans"
            placeholder={current.placeholder}
            value={formData[current.field] || ''}
            onChange={(e) => setFormData({ ...formData, [current.field]: e.target.value })}
          />
        </motion.div>
      </AnimatePresence>

      <div className="flex justify-between pt-4">
        <button
          onClick={handlePrev}
          disabled={currentStep === 0}
          className="px-6 py-3 rounded-xl border border-white/10 text-white/50 disabled:opacity-0 flex items-center gap-2 hover:bg-white/5 transition-all"
        >
          <ArrowRight className="w-5 h-5" />
          السابق
        </button>
        
        <button
          onClick={handleNext}
          className="px-8 py-3 bg-brand-gold text-brand-deep font-bold rounded-xl flex items-center gap-2 hover:glow-gold transition-all"
        >
          {currentStep === steps.length - 1 ? "إطلاق الهدف" : "التالي"}
          {currentStep === steps.length - 1 ? <Check className="w-5 h-5" /> : <ArrowLeft className="w-5 h-5" />}
        </button>
      </div>
    </div>
  );
};
