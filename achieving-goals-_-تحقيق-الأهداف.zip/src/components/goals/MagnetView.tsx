import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Brain, Magnet, Zap } from 'lucide-react';
import { Goal } from '../../context/GoalContext';

interface MagnetViewProps {
  goal: Goal;
}

export const MagnetView: React.FC<MagnetViewProps> = ({ goal }) => {
  const intensity = goal.intensity || 20;

  return (
    <div className="relative w-full h-[400px] flex items-center justify-center overflow-hidden ritual-bg rounded-3xl border border-white/10">
      {/* Background Aura Waves */}
      <AnimatePresence>
        {[...Array(3)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ 
              scale: [1, 2 + i * 0.5], 
              opacity: [0.3, 0],
              borderColor: [goal.visualAuraColor || '#00f2ff', 'transparent']
            }}
            transition={{ 
              duration: 4, 
              delay: i * 1.5, 
              repeat: Infinity, 
              ease: "easeOut" 
            }}
            className="absolute rounded-full border-2"
            style={{ width: '200px', height: '200px' }}
          />
        ))}
      </AnimatePresence>

      {/* The Central Brain & Magnet */}
      <div className="relative z-10 flex flex-col items-center gap-4">
        <motion.div
          animate={{ 
            y: [0, -10, 0],
            filter: [`drop-shadow(0 0 10px ${goal.visualAuraColor})`, `drop-shadow(0 0 30px ${goal.visualAuraColor})`, `drop-shadow(0 0 10px ${goal.visualAuraColor})`]
          }}
          transition={{ duration: 3, repeat: Infinity }}
          className="relative"
        >
          <Brain className="w-24 h-24 text-white" />
          <motion.div
            animate={{ rotate: [0, 360] }}
            transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
            className="absolute -top-2 -right-2"
          >
            <Zap className="w-6 h-6 text-brand-gold fill-brand-gold" />
          </motion.div>
        </motion.div>

        <motion.div
          animate={{ scale: [1, 1.1, 1] }}
          className="flex flex-col items-center"
        >
          <Magnet className="w-16 h-16 text-brand-gold transform rotate-180" />
          <div className="mt-2 px-4 py-1 rounded-full glass text-xs font-mono tracking-widest text-brand-cyan uppercase">
            Intensity: {intensity}%
          </div>
        </motion.div>
      </div>

      {/* Floating Particles to target */}
      <div className="absolute inset-x-0 top-0 bottom-0 pointer-events-none">
        {[...Array(12)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ 
              x: Math.random() * 400 - 200, 
              y: -50, 
              opacity: 0,
              scale: 0.5
            }}
            animate={{ 
              y: [0, 200], 
              x: [Math.random() * 400 - 200, 0], 
              opacity: [0, 1, 0] 
            }}
            transition={{ 
              duration: 2 + Math.random() * 2, 
              delay: Math.random() * 5, 
              repeat: Infinity 
            }}
            className="absolute left-1/2 w-1 h-1 bg-brand-gold rounded-full"
          />
        ))}
      </div>

      <div className="absolute bottom-6 text-center px-4">
        <h3 className="text-xl font-display italic text-brand-gold truncate max-w-xs">{goal.desire}</h3>
      </div>
    </div>
  );
};
