import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { GoalProvider, useGoals } from './context/GoalContext';
import { AuthOverlay } from './components/auth/AuthOverlay';
import { Navbar } from './components/layout/Navbar';
import { RitualStepper } from './components/goals/RitualStepper';
import { MagnetView } from './components/goals/MagnetView';
import { Toaster } from 'react-hot-toast';
import { Plus, Target, Sparkles, Clock, ChevronLeft } from 'lucide-react';
import { AR } from './constants';
import { motion, AnimatePresence } from 'motion/react';

const Dashboard = () => {
  const { goals, loading } = useGoals();
  const [showRitual, setShowRitual] = useState(false);
  const [selectedGoal, setSelectedGoal] = useState<any>(null);

  if (loading) return (
    <div className="flex items-center justify-center min-h-screen">
      <div className="w-12 h-12 border-4 border-brand-gold border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <main className="pt-28 pb-12 px-6 max-w-7xl mx-auto" dir="rtl">
      <AnimatePresence>
        {showRitual ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex flex-col items-center justify-center min-h-[70vh]"
          >
            <button 
              onClick={() => setShowRitual(false)}
              className="self-end mb-6 text-white/50 flex items-center gap-2 hover:text-white"
            >
              إلغاء
              <ChevronLeft className="w-5 h-5 rotate-180" />
            </button>
            <RitualStepper onComplete={() => setShowRitual(false)} />
          </motion.div>
        ) : selectedGoal ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-8"
          >
             <button 
              onClick={() => setSelectedGoal(null)}
              className="text-white/50 flex items-center gap-2 hover:text-white mb-6"
            >
              العودة للوحة الأهداف
              <ChevronLeft className="w-5 h-5 rotate-180" />
            </button>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div className="space-y-6">
                <h1 className="text-4xl font-display font-bold text-brand-gold">{selectedGoal.desire}</h1>
                <div className="glass p-6 rounded-2xl space-y-4 border-brand-gold/10">
                  <div className="flex items-center gap-2 text-brand-gold/70 italic">
                    <Target className="w-5 h-5" />
                    <span>الرؤية والهدف</span>
                  </div>
                  <p className="text-xl leading-relaxed text-white/90">{selectedGoal.why}</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="glass p-4 rounded-xl border-white/5">
                    <span className="text-xs uppercase tracking-widest text-white/30 block mb-2">التضحية</span>
                    <p className="text-sm font-medium">{selectedGoal.sacrifice || 'لم يحدد'}</p>
                  </div>
                  <div className="glass p-4 rounded-xl border-white/5">
                    <span className="text-xs uppercase tracking-widest text-white/30 block mb-2">النذر</span>
                    <p className="text-sm font-medium">{selectedGoal.vow || 'لم يحدد'}</p>
                  </div>
                </div>

                <div className="p-6 bg-brand-gold/5 rounded-2xl border border-brand-gold/20">
                  <h3 className="font-bold mb-4 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-brand-gold" />
                    تحصين الأوقات
                  </h3>
                  <div className="grid grid-cols-5 gap-2">
                    {Object.entries(AR.prayers).map(([key, label]) => (
                      <div key={key} className="flex flex-col items-center gap-2">
                        <div className="w-10 h-10 rounded-full border border-brand-gold/20 flex items-center justify-center text-[10px] text-brand-gold/60 text-center px-1">
                          {key.toUpperCase()}
                        </div>
                        <span className="text-[10px] opacity-40 text-center">{label.split(' ')[0]}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="space-y-6">
                <MagnetView goal={selectedGoal} />
                <div className="text-center italic opacity-40 text-sm">
                  "أنا عند حسن ظن عبدي بي"
                </div>
              </div>
            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="space-y-12"
          >
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
              <div>
                <h1 className="text-5xl font-display font-bold mb-3">{AR.appName}</h1>
                <p className="text-white/40 text-lg">أهلاً بك في عالمك الجديد.. حيث الأفكار تتحول إلى حقيقة.</p>
              </div>
              <button
                onClick={() => setShowRitual(true)}
                className="px-8 py-4 bg-brand-gold text-brand-deep font-bold rounded-2xl shadow-xl shadow-brand-gold/20 flex items-center gap-3 hover:scale-105 transition-all group active:scale-95"
              >
                <Plus className="w-6 h-6" />
                إطلاق رغبة جديدة
                <Sparkles className="w-5 h-5 group-hover:rotate-12 transition-transform" />
              </button>
            </div>

            {goals.length === 0 ? (
              <div className="py-20 text-center glass rounded-3xl border-dashed border-white/10">
                <Target className="w-16 h-16 mx-auto mb-4 text-white/10" />
                <p className="text-xl text-white/30">لم تطلق أي أهداف بعد.. ابدأ اليوم.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {goals.map(goal => (
                  <motion.div
                    key={goal.id}
                    layoutId={goal.id}
                    onClick={() => setSelectedGoal(goal)}
                    className="glass p-6 rounded-3xl group cursor-pointer hover:border-brand-gold/30 transition-all border-white/5"
                  >
                    <div className="flex justify-between items-start mb-6">
                      <div className="w-12 h-12 bg-white/5 rounded-xl flex items-center justify-center group-hover:bg-brand-gold/10 transition-colors">
                        <Target className="w-6 h-6 text-white/40 group-hover:text-brand-gold" />
                      </div>
                      <div className="text-xs font-mono text-white/20 uppercase tracking-tighter">
                        Active Magnet
                      </div>
                    </div>
                    
                    <h3 className="text-2xl font-display font-bold mb-4 line-clamp-2">{goal.desire}</h3>
                    
                    <div className="space-y-4 pt-4 border-t border-white/5">
                      <div className="w-full bg-white/5 h-1.5 rounded-full overflow-hidden">
                        <motion.div 
                          className="h-full bg-brand-gold"
                          initial={{ width: 0 }}
                          animate={{ width: `${goal.intensity}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs text-white/30 uppercase tracking-widest">
                        <span>قوة الجذب</span>
                        <span>{goal.intensity}%</span>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </main>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <GoalProvider>
        <div className="min-h-screen ritual-bg selection:bg-brand-gold selection:text-brand-deep">
          <Navbar />
          <Dashboard />
          <AuthOverlay />
          <Toaster 
            position="bottom-left"
            toastOptions={{
              style: {
                background: '#1a1b26',
                color: '#fff',
                border: '1px solid rgba(255,255,255,0.1)',
                borderRadius: '16px'
              },
              iconTheme: {
                primary: '#ffcc00',
                secondary: '#1a1b26'
              }
            }}
          />
        </div>
      </GoalProvider>
    </AuthProvider>
  );
}
