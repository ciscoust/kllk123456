export const AR = {
  appName: "تحقيق الأهداف",
  motto: "تفاءلوا بالخير تجدوه",
  steps: {
    target: "حدد الهدف",
    desire: "ماذا تريد؟",
    worthiness: "هل تستحق؟",
    obstacles: "إزالة العوائق",
    preparation: "ماذا أعددت؟",
    sacrifice: "التضحية والقربان",
    vow: "النذر والعهد",
    visualization: "التخيل والامتنان"
  },
  booster: {
    rituals: "أوقات الدعاء",
    magnet: "تشغيل المغناطيس",
    boost: "تعزيز قوة الجذب"
  },
  prayers: {
    fajr: "الفجر (أطلق بوضوح)",
    dhuhr: "الظهر (الإيمان بها)",
    asr: "العصر",
    maghrib: "المغرب",
    isha: "العشاء"
  },
  auth: {
    login: "تسجيل الدخول باستخدام جوجل",
    logout: "تسجيل الخروج"
  }
};
