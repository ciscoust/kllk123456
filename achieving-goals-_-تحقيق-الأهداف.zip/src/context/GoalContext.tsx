import React, { createContext, useContext, useEffect, useState } from 'react';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { collection, query, where, onSnapshot, addDoc, updateDoc, doc, serverTimestamp, orderBy } from 'firebase/firestore';
import { useAuth } from './AuthContext';

export interface Goal {
  id: string;
  userId: string;
  desire: string;
  why?: string;
  worthiness?: string;
  obstacles?: string;
  preparation?: string;
  sacrifice?: string;
  sacrificeValue?: string;
  offering?: string;
  vow?: string;
  covenant?: string;
  status: 'active' | 'achieved' | 'archived';
  intensity: number;
  visualAuraColor: string;
  createdAt: any;
}

interface GoalContextType {
  goals: Goal[];
  loading: boolean;
  addGoal: (goal: Partial<Goal>) => Promise<void>;
  updateGoal: (id: string, updates: Partial<Goal>) => Promise<void>;
}

const GoalContext = createContext<GoalContextType | undefined>(undefined);

export const GoalProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [goals, setGoals] = useState<Goal[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setGoals([]);
      setLoading(false);
      return;
    }

    const q = query(
      collection(db, 'goals'),
      where('userId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const g = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Goal));
      setGoals(g);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'goals');
    });

    return () => unsubscribe();
  }, [user]);

  const addGoal = async (goal: Partial<Goal>) => {
    if (!user) return;
    try {
      await addDoc(collection(db, 'goals'), {
        ...goal,
        userId: user.uid,
        status: 'active',
        intensity: 20,
        visualAuraColor: '#00f2ff',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'goals');
    }
  };

  const updateGoal = async (id: string, updates: Partial<Goal>) => {
    try {
      const goalDoc = doc(db, 'goals', id);
      await updateDoc(goalDoc, {
        ...updates,
        updatedAt: serverTimestamp()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `goals/${id}`);
    }
  };

  return (
    <GoalContext.Provider value={{ goals, loading, addGoal, updateGoal }}>
      {children}
    </GoalContext.Provider>
  );
};

export const useGoals = () => {
  const context = useContext(GoalContext);
  if (context === undefined) {
    throw new Error('useGoals must be used within a GoalProvider');
  }
  return context;
};
